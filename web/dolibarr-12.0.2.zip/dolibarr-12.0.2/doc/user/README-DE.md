README (german)
LiesMich (deutsch)

--------------------------------
Benutzeranleitung
--------------------------------

Alle Dolibarr-Informationen sind online verfuegbar ueber die Webseiten:
https://www.dolibarr.de 
oder
https://www.dolibarr.org
https://wiki.dolibarr.org
